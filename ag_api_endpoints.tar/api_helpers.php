<?php
require_once dirname(__FILE__) . '/../config.php';
require_once('MDB2.php');
require_once('Rest.inc.php');

class ApiHelpers {
  var $db;
  var $pear;
  var $error;

  function init() {
    global $appConfig;
    $dsn = $appConfig['dsn'];

    $this->db = MDB2::connect($dsn, null);
    $this->pear = new PEAR();
    if ($this->pear->isError($db)) {
       error_log("Error connecting to database");
    }
  }

  function getError() {
    $result = $error;
    $this->error = null;
    return $result;
  }

  // Get the assessment type for this assessment
  function getAssessmentType($id) {
    if (!$this->db) {
      $this->init();
    }
    if (!$this->db) {
      $this->error = "Error connecting to database";
    }

    $result = $this->db->query("select type from assessment where assessment_id=".$id);
    if ($this->pear->isError($result)) {
       error_log("Error executing query");
       $this->error("Unable to locate the given api_key", 404);
    }

    // Get the assessment type (simple or type based)
    $type = null;
    while($row = $result->fetchRow(MDB2_FETCHMODE_ASSOC)) {
       $type = $row['type'];
    }

    return $type;
  }

  // Get the types for a type-based assessment
  function getTypes($id) {
    $result = $this->db->query("select type_based from type_based where assessment_id=".$id);
    if ($this->pear->isError($result)) {
       error_log("Error retrieving types for assessment_id ".$id);
       $this->error("Unable to get types", 500);
    }

    $types = array();
    while($row = $result->fetchRow(MDB2_FETCHMODE_ASSOC)) {
       $types[] = $row['type_based'];
    }

    return $types;
  }

  function cleanKeys($key) {
    $key = str_replace(' ', '_', $key);
    $key = str_replace(',', '', $key);
    return strtolower($key);
  }
}
 ?>
