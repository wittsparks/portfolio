<?php
require_once('../config.php');
require_once('MDB2.php');
require_once('Rest.inc.php');

global $appConfig;

$dsn = $appConfig['dsn'];
$db = MDB2::connect($dsn, null);
$pear = new PEAR();
if ($pear->isError($db)) {
   error_log("Error connecting to database");
   $rest->response("Internal Error", 500);
}

$rest = new REST();

// Get the user_id associated with this api_key
$result = $db->query("select user_id from user where api_key like '".$_GET['api_key']."'");
if ($pear->isError($result)) {
   error_log("Error executing query");
   $rest->response("Unable to locate the given api_key", 404);
}

while($row = $result->fetchRow(MDB2_FETCHMODE_ASSOC)) {
   $user_id = $row['user_id'];
}

// Get the list of assessments for this user
$result = $db->query("select assessment_id as id, title from assessment where user_id=".$user_id);
if ($pear->isError($result)) {
   error_log("Error retrieving assessment list for user_id ".$user_id);
   $rest->response("Unable to get the assessment list", 500);
}

$assessments = array();
while($row = $result->fetchRow(MDB2_FETCHMODE_ASSOC)) {
   $assessments[] = $row;
}

$rest->response(json_encode($assessments), 200);

?>
