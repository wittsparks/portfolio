<?php
require_once('../config.php');
require_once('MDB2.php');
require_once('Rest.inc.php');

global $appConfig;

$dsn = $appConfig['dsn'];
$db = MDB2::connect($dsn, null);
$pear = new PEAR();
if ($pear->isError($db)) {
   error_log("Error connecting to database");
   $rest->response("Internal Error", 500);
}

$rest = new REST();

// make sure the given API key is valid
$result = $db->query("select user_id from user where api_key like '".$_GET['api_key']."'");
if ($pear->isError($result)) {
   error_log("Error executing query");
   $rest->response("Unable to locate the given api_key", 401);
}

while($row = $result->fetchRow(MDB2_FETCHMODE_ASSOC)) {
   $user_id = $row['user_id'];
}

// Get the POST content sent by Zapier
error_log("unsubscribe:");
error_log(var_export($_GET, true));

// Remove the zapier webhook URL from the given assessment
$query_str = "update assessment set zapier_webhook_url=NULL".
	" where assessment_id=".$_GET['assessment_id'];

$result = $db->query($query_str);

if ($pear->isError($result)) {
	error_log("Error removing subscription from Zapier for assessment_id ".$_GET['assessment_id']);
	$rest->response("Error removing subscription", 500);
}

$rest->response("", 200);
?>
