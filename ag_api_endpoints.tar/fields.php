<?php
require_once('../config.php');
require_once('api_helpers.php');
require_once('Rest.inc.php');

$rest = new REST();
$apiHelpers = new ApiHelpers();

$type = $apiHelpers->getAssessmentType($_GET['assessment_id']);
if (!$type) {
  $rest->response($apiHelpers->getError(), 500);
  return;
}

$addl_fields = array();

// for type based, get the list of types
if ($type == 'Type-based') {
  $types = $apiHelpers->getTypes($_GET['assessment_id']);
  if (!$types) {
    $rest->response($apiHelpers->getError(), 500);
    return;
  }

  $index = 0;
  foreach ($types as $type) {
    $addl_fields[$index]['important'] = false;
    $addl_fields[$index]['type'] = "unicode";
    $clean_type = $apiHelpers->cleanKeys($type);
    $addl_fields[$index]['key'] = $clean_type;
    $addl_fields[$index]['label'] = "Users score for ".$type;
    $index++;
  }
} else {
  $addl_fields['important'] = false;
  $addl_fields['type'] = "unicode";
  $addl_fields['key'] = "score";
  $addl_fields['label'] = "Assessment Score";
}

$static_fields = '[
  {
      "important": true,
      "type": "unicode",
      "key": "assessment_title",
      "label": "Title of assessment"
  },
  {
      "type": "unicode",
      "key": "date",
      "label": "Date assessment was taken"
  },
  {
      "important": true,
      "type": "unicode",
      "key": "email",
      "label": "Email Address"
  },
  {
      "important": true,
      "type": "unicode",
      "key": "first_name",
      "label": "First Name"
  },
  {
      "important": true,
      "type": "unicode",
      "key": "last_name",
      "label": "Last Name"
  },
  {
      "important": true,
      "type": "unicode",
      "key": "name",
      "label": "Full Name"
  },
  {
      "type": "unicode",
      "key": "time",
      "label": "Time assessment was taken"
  }
]';

$all_fields = json_decode($static_fields);

array_push($all_fields, $addl_fields);
$result = json_encode($all_fields);
var_dump($result);
exit;
$rest->response(json_encode($assessments), 200);

?>
