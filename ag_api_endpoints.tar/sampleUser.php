<?php
require_once('../config.php');
require_once('api_helpers.php');
require_once('Rest.inc.php');

$rest = new REST();
$apiHelpers = new ApiHelpers();

$static_response = '
[
   {
      "first_name":"Test",
      "last_name":"User",
      "email":"assessmentgenerator_test@assessmentgenerator.com",
      "assessment_title":"My Assessment",
      "date":"1-1-2000",
      "time":"16:06"
   }
]';

$static_array = json_decode($static_response);
$static_array = (array) $static_array[0];

// If this is a type based assessment, add items for each type
$type = $apiHelpers->getAssessmentType($_GET['assessment_id']);
if (!$type) {
  $rest->response("Couldn't find that assessment", 404);
}

if ($type == 'Type-based') {
  $types = $apiHelpers->getTypes($_GET['assessment_id']);

  foreach ($types as $type) {
    $type = $apiHelpers->cleanKeys($type);
    $static_array[strtolower($type)] = strval(rand(0,50));
  }
} else {
  $static_array['score'] = "25";
}

$outer_array[] = $static_array;
$sample_response = json_encode($outer_array);

$rest->response($sample_response, 200);

?>
